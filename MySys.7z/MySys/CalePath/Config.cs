using System.Configuration;


namespace MySys;
internal class Config
{
    /// <summary>シングルトンパターン</summary>
    private static Config instance;

    Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

    public static Config GetInstance()
    {
        if (instance == null)
            instance = new Config();
        return instance;
    }

    public int targetNum { get; set; }


    public void InitConfig(string text)
    {
        if (!config.AppSettings.Settings.AllKeys.Contains(text))
        {
            var a = reString(text);
            config.AppSettings.Settings.Add(text, "0");
            config.AppSettings.Settings.Add(a, "1");
        }
            
        SetConfig(text);          
    }

    public void SetConfig(string key)
    {
        var strTargetNum = string.Format("{0}_targetNum", key);

        targetNum = int.Parse(config.AppSettings.Settings[strTargetNum].Value);

    }

    private string reString(string key)
    {
        var strTargetNum = string.Format("{0}_targetNum", key);

        return strTargetNum;
    }

    public void SaveConfig(string key)
    {
        var a = reString(key);

        config.AppSettings.Settings[key].Value = "0";
        config.AppSettings.Settings[a].Value = targetNum.ToString();

        config.Save();
    }
}