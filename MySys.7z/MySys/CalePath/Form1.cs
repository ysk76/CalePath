using System.Text;
using Microsoft.VisualBasic.FileIO;


namespace MySys;
public partial class Form1 : Form
{
    string[] array;
    string[] colHeader = ["カレンダID", "JP1_Path"];

    readonly string ExeDirPath = Path.GetDirectoryName(Application.ExecutablePath);

    enum ColName
    {
        CmdCol = 0,
        CaleCol,
        PathCol
    }

    public Form1()
    {
        InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
        //エンコーダーを登録
        Encoding.RegisterProvider(CodePagesEncodingProvider.Instance);
    }

    private void dataGridView1_KeyPress(object sender, KeyPressEventArgs e)
    {
        if (e.KeyChar == 22)
            PasteData();
    }

    private void PasteData()
    {
        dataGridView1.RowCount = 0;
        // クリップボードからテキストを取得
        string clipboardText = Clipboard.GetText().Trim();

        array = clipboardText.Split("\r\n");

        for (int i = 0; i < array.Length; i++)
        {
            if (!string.IsNullOrWhiteSpace(array[i]))
                dataGridView1.Rows.Add(array[i].Trim());
        }

        //奇数行の背景色を変更
        dataGridView1.AlternatingRowsDefaultCellStyle.BackColor = Color.AliceBlue;
    }

    private void button1_Click(object sender, EventArgs e)
    {
        if (comboBox1.Text.Length == 0)
        {
            MessageBox.Show("サーバ名が空欄です。", "項目未入力", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            return;
        }

        if (dataGridView1.RowCount == 0)
        {
            MessageBox.Show("コマンド文が空欄です。", "項目未入力", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            return;
        }

        GetData();

        Config.GetInstance().targetNum = int.Parse(textBox1.Text);

        Config.GetInstance().SaveConfig(comboBox1.Text);
    }

    private void GetData()
    {
        string dataDirPath = Path.Combine(ExeDirPath, "Data");
        string dataPath = Path.Combine(dataDirPath, comboBox1.Text + ".txt");

        ReadCsv(dataPath);
    }

    private void ReadCsv(string path)
    {
        using (TextFieldParser txtParser = new TextFieldParser(path, Encoding.GetEncoding("shift_JIS")))
        {
            txtParser.SetDelimiters(",");
            while (!txtParser.EndOfData)
            {
                string[] values = txtParser.ReadFields();
                CheakData(values);
            }
        }
    }

    private void CheakData(string[] values)
    {
        int targetNum = 0;

        for (int i = 0; i < array.Length; i++)
        {
            //指定のコマンド文かチェック
            if (array[i].ToString() == values[int.Parse(textBox1.Text) - 1].Trim())
            {
                for(int n = 0; n < values.Length; n++)
                {
                    dataGridView1[n + 1, i].Value = values[n].Trim();
                }
            }
        }
    }

    private void comboBox1_DropDown(object sender, EventArgs e)
    {
        comboBox1.Items.Clear();

        string dataDirPath = Path.Combine(ExeDirPath, "Data");

        string[] folders = Directory.GetFiles(dataDirPath, "*.txt");

        foreach (var folder in folders)
        {
            string fileName = Path.GetFileNameWithoutExtension(folder);

            comboBox1.Items.Add(fileName);
        }
    }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
    {
        dataGridView1.ColumnCount = 0;

        string dataDirPath = Path.Combine(ExeDirPath, "Data");
        string dataPath = Path.Combine(dataDirPath, comboBox1.Text + ".txt");

        textConfig(comboBox1.Text);

        ReadFirstCsv(dataPath);
    }

    private void ReadFirstCsv(string path)
    {
        using (TextFieldParser txtParser = new TextFieldParser(path, Encoding.GetEncoding("shift_JIS")))
        {
            txtParser.SetDelimiters(",");

            string[] values = txtParser.ReadFields();

            var col2 = new DataGridViewColumn();
            col2.Name = "検索値";
            col2.HeaderText = "検索値";
            col2.CellTemplate = new DataGridViewTextBoxCell();

            dataGridView1.Columns.Add(col2);

            for (int i = 0; i < colHeader.Length; i++)
            {
                var col = new DataGridViewColumn();
                col.Name = colHeader[i];
                col.HeaderText = colHeader[i];
                col.CellTemplate = new DataGridViewTextBoxCell();

                dataGridView1.Columns.Add(col);
            }
        }
    }

    private void textConfig(string text)
    {
        Config.GetInstance().InitConfig(text);

        textBox1.Text = Config.GetInstance().targetNum.ToString();
    }

}
