﻿namespace MySys;

partial class Form1
{
    /// <summary>
    ///  Required designer variable.
    /// </summary>
    private System.ComponentModel.IContainer components = null;

    /// <summary>
    ///  Clean up any resources being used.
    /// </summary>
    /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }
        base.Dispose(disposing);
    }

    #region Windows Form Designer generated code

    /// <summary>
    ///  Required method for Designer support - do not modify
    ///  the contents of this method with the code editor.
    /// </summary>
    private void InitializeComponent()
    {
        button1 = new Button();
        comboBox1 = new ComboBox();
        dataGridView1 = new DataGridView();
        groupBox1 = new GroupBox();
        label1 = new Label();
        textBox1 = new TextBox();
        ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
        groupBox1.SuspendLayout();
        SuspendLayout();

        // 
        // button1
        // 
        button1.Anchor = AnchorStyles.Bottom | AnchorStyles.Left;
        button1.Location = new Point(12, 363);
        button1.Name = "button1";
        button1.Size = new Size(132, 32);
        button1.TabIndex = 4;
        button1.Text = "データ取得";
        button1.UseVisualStyleBackColor = true;
        button1.Click += button1_Click;
        // 
        // comboBox1
        // 
        comboBox1.FormattingEnabled = true;
        comboBox1.Location = new Point(6, 22);
        comboBox1.Name = "comboBox1";
        comboBox1.Size = new Size(121, 23);
        comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        comboBox1.TabIndex = 0;
        comboBox1.DropDown += comboBox1_DropDown;
        comboBox1.SelectedIndexChanged += comboBox1_SelectedIndexChanged;
        // 
        // dataGridView1
        // 
        dataGridView1.AllowUserToAddRows = false;
        dataGridView1.AllowUserToDeleteRows = false;
        dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dataGridView1.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithoutHeaderText;
        dataGridView1.AllowUserToAddRows = false;
        dataGridView1.RowHeadersVisible = false;
        dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dataGridView1.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        dataGridView1.RowsDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        dataGridView1.ReadOnly = true;
        dataGridView1.Location = new Point(150, 12);
        dataGridView1.Name = "dataGridView1";
        dataGridView1.Size = new Size(518, 383);
        dataGridView1.TabIndex = 1;
        dataGridView1.KeyPress += dataGridView1_KeyPress;
        // 
        // groupBox1
        // 
        groupBox1.Controls.Add(comboBox1);
        groupBox1.Location = new Point(12, 12);
        groupBox1.Name = "groupBox1";
        groupBox1.Size = new Size(132, 54);
        groupBox1.TabIndex = 5;
        groupBox1.TabStop = false;
        groupBox1.Text = "ファイル名";
        // 
        // label1
        // 
        label1.AutoSize = true;
        label1.Location = new Point(15, 75);
        label1.Name = "label1";
        label1.Size = new Size(43, 15);
        label1.TabIndex = 3;
        label1.Text = "検索値";
        // 
        // textBox1
        // 
        textBox1.Location = new Point(64, 72);
        textBox1.Name = "textBox1";
        textBox1.Size = new Size(80, 23);
        textBox1.TabIndex = 0;

        this.components = new System.ComponentModel.Container();
        this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
        this.ClientSize = new System.Drawing.Size(800, 450);
        this.Text = "Form1";
        Controls.Add(label1);
        Controls.Add(textBox1);
        Controls.Add(groupBox1);
        Controls.Add(dataGridView1);
        Controls.Add(button1);
        Name = "Form1";
        Text = "FCalePath";
        Load += Form1_Load;
        ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
        groupBox1.ResumeLayout(false);
        ResumeLayout(false);
        PerformLayout();
    }

    private Button button1;
    private GroupBox groupBox1;
    private ComboBox comboBox1;
    private Label label1;
    private TextBox textBox1;
    private DataGridView dataGridView1;


    #endregion
}
